import 'package:flutter/material.dart';

var MyItems = [
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/307007947_1148608179058883_5983143140396414337_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeHKfzebhRzz_t9BvjdPzmMaUhS65reBurhSFLrmt4G6uNURpDBnAh1d4IuxjdDzK-VtBuZVDj1liWhG7383W26H&_nc_ohc=XOSQgcDNfTgAX9qOpfV&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfCtjZMJJCN9QqV9aEcUEUMt-voVQnV2gg8iXeuDwa4Nag&oe=638D8D4C",
    "description": "I am Sojib.\nI am from Pabna.\nDaffodil International University.\nDepartment of CSE",
    "title": "Sojib"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/291726876_1249011912570883_6379583760089093800_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeE3fZLtRjjJYOzU4HIX95PkdwvGbApz6vJ3C8ZsCnPq8khFUVT3SFbeN4_sz6Iq0uknozfL_P4Ep05syy7A3d0W&_nc_ohc=XFKW8V61QP0AX-bF7nF&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfA0lhUWCAih3bOOXpjljosJ87jxhq9hy3YYI10Sxv-LVg&oe=638CD1E1",
    "description": "I am Partho.\nI am from Pabna.\nMarine Engineer",
    "title": "Partho"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/311822473_416669957283809_4104981400184012873_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeG6gIqxncW7svebmP40VZeB8F8_zVgIo7TwXz_NWAijtM0EhAGgyVPh5Tk3Qwpmn4VR2aggY3iw0F2fkFzpE41P&_nc_ohc=mceChA1QMw4AX_1tSTn&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfDxXaSXtmfSq-JHFE1i4ulNKSjtxjs2281s8G6ptpHCiw&oe=638D5D28",
    "description": "I am Alam.\nI am from Pabna.\nDepartment of CE",
    "title": "Alam"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t1.6435-9/40353168_250253212490154_8718240649704374272_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=8bfeb9&_nc_eui2=AeGV3qXj6IJSU4n9MON0gZ91MBiEeBQbUwIwGIR4FBtTAqGjMWTkzQ3CNFpsdq504inRDra0kR0ZL_fjns977xZa&_nc_ohc=i0uwnvdb1OIAX_8KSTh&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfCeXM7maAHeDzt-9b3YHRvHCFeYqJvgoMEPU3-yus0h1Q&oe=63B00CDA",
    "description": "I am Anis.\nI am from Pabna.\nI am a Student",
    "title": "Anis"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/312737566_526554485949082_6197790400154108658_n.jpg?stp=dst-jpg_p843x403&_nc_cat=109&ccb=1-7&_nc_sid=730e14&_nc_eui2=AeEhrER7vBv9sIkPKjLfaQAf8mpDuoqgefXyakO6iqB59UQbaiyudoHBQuVmH5qRjxVpNn61H6Udtv2RtlrqcPBQ&_nc_ohc=rNUc6UOa5PAAX_jP6-x&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfAyl6wZqnOC4Bt514fTKljrkcmmu61WG3NyD1VcI7PQPg&oe=638E0DAE",
    "description": "I am Masud.\nI am from Pabna.\nI am a Student",
    "title": "Masud"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/310160246_1301877030619366_626230329445793333_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeH9f0j5Nl0nB-jCVdXhXX3O7GRm9FeUAXTsZGb0V5QBdK0x8bnxHKJpieFbw05pnNdeg2v4fGLPGvXrb1KisLqQ&_nc_ohc=R0tNRx27P7kAX892Qd3&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfDZJDIFFCCGqX3gvjepfrkJCG1Itkp-k-WwHKrXUPnxpA&oe=638DCD92",
    "description": "I am Maruf.\nI am from Pabna.\nI am a Student",
    "title": "Maruf"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/307007947_1148608179058883_5983143140396414337_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeHKfzebhRzz_t9BvjdPzmMaUhS65reBurhSFLrmt4G6uNURpDBnAh1d4IuxjdDzK-VtBuZVDj1liWhG7383W26H&_nc_ohc=XOSQgcDNfTgAX9qOpfV&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfCtjZMJJCN9QqV9aEcUEUMt-voVQnV2gg8iXeuDwa4Nag&oe=638D8D4C",
    "description": "I am Sojib.\nI am from Pabna.\nDaffodil International University.\nDepartment of CSE",
    "title": "Sojib"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/291726876_1249011912570883_6379583760089093800_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeE3fZLtRjjJYOzU4HIX95PkdwvGbApz6vJ3C8ZsCnPq8khFUVT3SFbeN4_sz6Iq0uknozfL_P4Ep05syy7A3d0W&_nc_ohc=XFKW8V61QP0AX-bF7nF&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfA0lhUWCAih3bOOXpjljosJ87jxhq9hy3YYI10Sxv-LVg&oe=638CD1E1",
    "description": "I am Partho.\nI am from Pabna.\nMarine Engineer",
    "title": "Partho"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/310160246_1301877030619366_626230329445793333_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeH9f0j5Nl0nB-jCVdXhXX3O7GRm9FeUAXTsZGb0V5QBdK0x8bnxHKJpieFbw05pnNdeg2v4fGLPGvXrb1KisLqQ&_nc_ohc=R0tNRx27P7kAX892Qd3&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfDZJDIFFCCGqX3gvjepfrkJCG1Itkp-k-WwHKrXUPnxpA&oe=638DCD92",
    "description": "I am Maruf.\nI am from Pabna.\nI am a Student",
    "title": "Maruf"
  },
  {
    "img":
        "https://scontent.fjsr14-1.fna.fbcdn.net/v/t39.30808-6/311822473_416669957283809_4104981400184012873_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeG6gIqxncW7svebmP40VZeB8F8_zVgIo7TwXz_NWAijtM0EhAGgyVPh5Tk3Qwpmn4VR2aggY3iw0F2fkFzpE41P&_nc_ohc=mceChA1QMw4AX_1tSTn&_nc_ht=scontent.fjsr14-1.fna&oh=00_AfDxXaSXtmfSq-JHFE1i4ulNKSjtxjs2281s8G6ptpHCiw&oe=638D5D28",
    "description": "I am Alam.\nI am from Pabna.\nDepartment of CE",
    "title": "Alam"
  },
];
