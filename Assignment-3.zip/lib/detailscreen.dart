import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  final items;

  DetailScreen(this.items);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        title: Text(items["title"]),
        centerTitle: true,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.network(items["img"],height: 300,width: double.infinity,),
          ),
          SizedBox(
            height: 30,
          ),
          Text(items["description"],style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 18),)
        ],
      ),
    );
  }
}
