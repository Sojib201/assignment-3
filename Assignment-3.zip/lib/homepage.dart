import 'package:flutter/material.dart';

import 'detailscreen.dart';
import 'json.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("AppBar"),
        centerTitle: true,
        backgroundColor: Colors.green,
      ),
      body: ListView.builder(
        itemCount: MyItems.length,
        itemBuilder: (context, index) {
          var items = MyItems[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DetailScreen(items)),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListTile(
                title: Center(child: Text(items["title"]!,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 25),)),
                leading: Image.network(items["img"]!,height: double.infinity,),

                tileColor: Colors.grey,
                enabled: true,
                minVerticalPadding: 30,
              ),
            ),
          );
        },
      ),
    );
  }
}
